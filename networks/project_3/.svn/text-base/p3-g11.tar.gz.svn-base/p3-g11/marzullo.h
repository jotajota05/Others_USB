
struct Par{
  int a;
  int b;
};


void bub(struct Linter*);


struct Par* Marzullo(struct Linter* ) ;
