void error(char *);

char *substring (size_t, size_t, const char *, char *, size_t);


